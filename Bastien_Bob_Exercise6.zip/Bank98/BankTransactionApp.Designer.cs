﻿namespace Bank98
{
    partial class BankTransactionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.accountNumberTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.accountBalanceTextBox = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.transactionStatusTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.submitButton = new System.Windows.Forms.Button();
            this.transactionAmountTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.rbWithdraw = new System.Windows.Forms.RadioButton();
            this.rbDeposit = new System.Windows.Forms.RadioButton();
            this.getHistoryButton = new System.Windows.Forms.Button();
            this.getStatusButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.AccountHistoryList = new System.Windows.Forms.ListBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(108, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(267, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "Account Number:";
            // 
            // accountNumberTextBox
            // 
            this.accountNumberTextBox.Location = new System.Drawing.Point(366, 42);
            this.accountNumberTextBox.Name = "accountNumberTextBox";
            this.accountNumberTextBox.Size = new System.Drawing.Size(396, 44);
            this.accountNumberTextBox.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(931, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(267, 37);
            this.label2.TabIndex = 2;
            this.label2.Text = "Account Balance:";
            // 
            // accountBalanceTextBox
            // 
            this.accountBalanceTextBox.Location = new System.Drawing.Point(1209, 42);
            this.accountBalanceTextBox.Name = "accountBalanceTextBox";
            this.accountBalanceTextBox.Size = new System.Drawing.Size(344, 44);
            this.accountBalanceTextBox.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.transactionStatusTextBox);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.submitButton);
            this.groupBox1.Controls.Add(this.transactionAmountTextBox);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.rbWithdraw);
            this.groupBox1.Controls.Add(this.rbDeposit);
            this.groupBox1.Location = new System.Drawing.Point(12, 163);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1900, 568);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Transaction Type";
            // 
            // transactionStatusTextBox
            // 
            this.transactionStatusTextBox.Location = new System.Drawing.Point(345, 466);
            this.transactionStatusTextBox.Name = "transactionStatusTextBox";
            this.transactionStatusTextBox.Size = new System.Drawing.Size(826, 44);
            this.transactionStatusTextBox.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(50, 474);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(277, 37);
            this.label4.TabIndex = 5;
            this.label4.Text = "Transaction Satus";
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(41, 365);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(261, 53);
            this.submitButton.TabIndex = 4;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.SubmitButton_Click);
            // 
            // transactionAmountTextBox
            // 
            this.transactionAmountTextBox.Location = new System.Drawing.Point(345, 272);
            this.transactionAmountTextBox.Name = "transactionAmountTextBox";
            this.transactionAmountTextBox.Size = new System.Drawing.Size(538, 44);
            this.transactionAmountTextBox.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 272);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(316, 37);
            this.label3.TabIndex = 2;
            this.label3.Text = "Transaction Amount:";
            // 
            // rbWithdraw
            // 
            this.rbWithdraw.AutoSize = true;
            this.rbWithdraw.Location = new System.Drawing.Point(34, 183);
            this.rbWithdraw.Name = "rbWithdraw";
            this.rbWithdraw.Size = new System.Drawing.Size(221, 41);
            this.rbWithdraw.TabIndex = 1;
            this.rbWithdraw.TabStop = true;
            this.rbWithdraw.Text = "Withdrawal";
            this.rbWithdraw.UseVisualStyleBackColor = true;
            // 
            // rbDeposit
            // 
            this.rbDeposit.AutoSize = true;
            this.rbDeposit.Location = new System.Drawing.Point(34, 66);
            this.rbDeposit.Name = "rbDeposit";
            this.rbDeposit.Size = new System.Drawing.Size(169, 41);
            this.rbDeposit.TabIndex = 0;
            this.rbDeposit.TabStop = true;
            this.rbDeposit.Text = "Deposit";
            this.rbDeposit.UseVisualStyleBackColor = true;
            // 
            // getHistoryButton
            // 
            this.getHistoryButton.Location = new System.Drawing.Point(53, 737);
            this.getHistoryButton.Name = "getHistoryButton";
            this.getHistoryButton.Size = new System.Drawing.Size(286, 89);
            this.getHistoryButton.TabIndex = 5;
            this.getHistoryButton.Text = "Get History";
            this.getHistoryButton.UseVisualStyleBackColor = true;
            this.getHistoryButton.Click += new System.EventHandler(this.GetHistoryButton_Click);
            // 
            // getStatusButton
            // 
            this.getStatusButton.Location = new System.Drawing.Point(463, 723);
            this.getStatusButton.Name = "getStatusButton";
            this.getStatusButton.Size = new System.Drawing.Size(299, 103);
            this.getStatusButton.TabIndex = 6;
            this.getStatusButton.Text = "Get Status";
            this.getStatusButton.UseVisualStyleBackColor = true;
            this.getStatusButton.Click += new System.EventHandler(this.GetStatusButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(1692, 723);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(225, 102);
            this.closeButton.TabIndex = 7;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.CloseButton_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1906, 40);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(251, 37);
            this.label5.TabIndex = 8;
            this.label5.Text = "Account History:";
            // 
            // AccountHistoryList
            // 
            this.AccountHistoryList.FormattingEnabled = true;
            this.AccountHistoryList.ItemHeight = 37;
            this.AccountHistoryList.Location = new System.Drawing.Point(1919, 143);
            this.AccountHistoryList.Name = "AccountHistoryList";
            this.AccountHistoryList.Size = new System.Drawing.Size(536, 485);
            this.AccountHistoryList.TabIndex = 10;
            // 
            // BankTransactionForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(19F, 37F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2467, 838);
            this.Controls.Add(this.AccountHistoryList);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.getStatusButton);
            this.Controls.Add(this.getHistoryButton);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.accountBalanceTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.accountNumberTextBox);
            this.Controls.Add(this.label1);
            this.Name = "BankTransactionForm";
            this.Text = "Bank Transaction Application";
            this.Load += new System.EventHandler(this.BankTransactionForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox accountNumberTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox accountBalanceTextBox;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox transactionStatusTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.TextBox transactionAmountTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton rbWithdraw;
        private System.Windows.Forms.RadioButton rbDeposit;
        private System.Windows.Forms.Button getHistoryButton;
        private System.Windows.Forms.Button getStatusButton;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox AccountHistoryList;
    }
}

