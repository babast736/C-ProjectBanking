﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank98
{
    public enum Status
    {
        Ok = 0,
        Overdrawn = 1,
        InsufficientFunds = 2,
        DepositTooLarge = 3


    }
    class BankAccount
    {
        private decimal currentBalance = 0;
        public string AccountNumber { get; set; }

        public List<string> History = new List<string>();
        
        Status currentStatus = new Status();
        public BankAccount(decimal initialBal, string accountNo)
        {
            currentBalance = initialBal;
            AccountNumber = accountNo;
            History = new List<string>();
            setHistory(currentBalance);
        }
        public Status Depoist(decimal money)
        {
            if (money > 1000)
            {
                return Status.DepositTooLarge;
            }
            else
            {

                currentBalance += money;
                setHistory(currentBalance);

            }
            return Status.Ok;
        }
        public Status Withdrawal(decimal money)
        {
            if ((currentBalance - money) > 0)
            {
                currentBalance = currentBalance - money;
                setHistory(currentBalance);
                return Status.Ok;
            }
            else if ((currentBalance - money) < 0 && (currentBalance - money) >= -100)
            {
                currentBalance = currentBalance - money;
                setHistory(currentBalance);
                return Status.Overdrawn;
            }
            else
            {
                return Status.InsufficientFunds;
            }
        }
        public Status GetAccountStatus()
        {
            if (currentBalance < 0)
                return Status.Overdrawn;
            else
                return Status.Ok;
        }
        public decimal AccountBalance()
        {
            return currentBalance;
        }
        private void setHistory(decimal curBal)
        {
            if (curBal < 0)
            {
                curBal = curBal * -1;
                History.Add("(" + curBal.ToString("C") + ")");
            }
            else History.Add(curBal.ToString("C"));
        }

    }
}

