﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank98
{
    public partial class BankTransactionForm : Form
    {
        BankAccount accObj;
        const string accountNumber = "000302019";
        const decimal initBalance = (decimal)132.59;
        public BankTransactionForm()
        {
            InitializeComponent();
            AccountHistoryList.DataSource = null;
            DisplayAccount();
        }

        private void DisplayAccount()
        {
            accObj = new BankAccount(initBalance, accountNumber);
            accountNumberTextBox.Text = accObj.AccountNumber.ToString();
            accountBalanceTextBox.Text = accObj.AccountBalance().ToString("C");
        }

        
        private void BankTransactionForm_Load(object sender, EventArgs e)
        {
            DisplayAccount();
            transactionAmountTextBox.Focus();
        }

        private void SubmitButton_Click(object sender, EventArgs e)
        {
            GetDepositBalance();
            GetWithdrawBalance();
            //reset
            transactionAmountTextBox.Text = "";
            rbDeposit.Checked = false;
            rbWithdraw.Checked = false;

        }

        private void GetDepositBalance()
        {
            //Deposit
            if (rbDeposit.Checked)
            {
                decimal amount;
                if (Decimal.TryParse(transactionAmountTextBox.Text, out amount))
                {

                    Status curStatus = accObj.Depoist(amount);
                    if (curStatus == Status.Ok)
                    {
                        transactionStatusTextBox.Text = "Transaction Successful";
                        accountBalanceTextBox.Text = accObj.AccountBalance().ToString("C2");
                    }
                    else if (curStatus == Status.DepositTooLarge)
                    {
                        transactionStatusTextBox.Text = "The transaction amount is too large ";
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a valid amount");
                }
            }
        }

        private void GetWithdrawBalance()
        {
            //Withdrawal
            if (rbWithdraw.Checked)
            {
                decimal amount;
                if (Decimal.TryParse(transactionAmountTextBox.Text, out amount))
                {
                    Status curStatus = accObj.Withdrawal(amount);
                    if (curStatus == Status.Ok)
                    {
                        transactionStatusTextBox.Text = "Transaction successful";
                        accountBalanceTextBox.Text = accObj.AccountBalance().ToString("C2");
                    }
                    else if (curStatus == Status.Overdrawn)
                    {
                        transactionStatusTextBox.Text = "Your account is overdrawn , please make a deposit";
                        accObj.Withdrawal((decimal)35.75);
                        accountBalanceTextBox.Text = accObj.AccountBalance().ToString("C2");
                    }
                    else if (curStatus == Status.InsufficientFunds)
                    {
                        transactionStatusTextBox.Text = "Your account  has insufficient funds";
                    }
                }
                else
                {
                    MessageBox.Show("Invalid input");
                }
            }
        }

        private void GetAccountBalance()
        {
            AccountHistoryList.DataSource = accObj.History.ToList();
        }

        private void GetStatusButton_Click(object sender, EventArgs e)
        {
            //Display current status

            if (accObj.GetAccountStatus() == Status.Ok)
            {
                MessageBox.Show("Your account is in good standing ");
            } else if (accObj.GetAccountStatus() == Status.Overdrawn)
            {
                MessageBox.Show("Your account is overdrawn.Please make a deposit");
            }
        }

        private void GetHistoryButton_Click(object sender, EventArgs e)
        {
            GetAccountBalance();
        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
